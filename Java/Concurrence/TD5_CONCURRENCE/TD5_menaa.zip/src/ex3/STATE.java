package ex3;

public enum STATE {
	BEGIN, IN_PROGRESS, FINISHED;
}
