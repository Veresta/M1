package ex1;

public enum STATE {
	VAL1HERE, NO_VALUE; 
}
